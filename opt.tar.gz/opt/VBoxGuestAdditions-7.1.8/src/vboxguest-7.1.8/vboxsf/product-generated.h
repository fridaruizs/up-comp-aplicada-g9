#ifndef ___product_generated_h___
#define ___product_generated_h___

#define VBOX_VENDOR "Oracle and/or its affiliates"
#define VBOX_VENDOR_SHORT "Oracle"
#define VBOX_PRODUCT "Oracle VirtualBox"
#define VBOX_PUEL_PRODUCT "Oracle VirtualBox Extension Pack"
#define VBOX_BUILD_PUBLISHER ""
#define VBOX_C_YEAR "2025"

#endif
